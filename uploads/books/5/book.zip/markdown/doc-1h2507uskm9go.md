系统架构文档（System Architecture Document）的形式，从**分层设计、模块职责、数据流、状态管理、外部依赖、扩展机制**等多个维度，全面剖析 MinDoc 这一 Go 项目。内容适合用于技术评审、二次开发规划或团队知识沉淀。


----

# **文档管理系统 —— 架构说明**


>**版本**：基于 `mindoc` 主流开源版本（Beego 1.x）
**目标读者**：Go 开发者、系统架构师、DevOps 工程师


----

## 一、整体架构概览（4+1 视图模型简化版）


|视图类型 |描述 |
|:--|
|**逻辑视图** |核心模块划分与交互（MVC + 服务层） |
|**开发视图** |项目目录结构与代码组织 |
|**进程视图** |单进程模型，无并发微服务 |
|**物理视图** |部署拓扑：单机部署，依赖 MySQL + 外部工具 |
|**场景视图** |关键用例：文档导出、协作编辑、权限控制 |


----

## 二、分层架构详解


### 2.1 用户交互层（Presentation Layer）


- **技术栈**：
	- 前端框架：jQuery 3.x + Bootstrap 3.2
	- Markdown 编辑器：`editor.md`（默认）、`cherry-markdown`（可选）
	- 文件上传：`WebUploader`（基于 Flash/HTML5）
	- 弹窗组件：`layer.js`

- **页面类型**：
	- 多页应用（MPA），非 SPA
	- 每个操作（如编辑、设置）跳转新页面或 AJAX 局部刷新

- **关键交互模式**：
	- 表单提交 → 后端重定向（Post-Redirect-Get）
	- AJAX 请求 → JSON 响应（`{"errcode":0, "errmsg":"ok"}`）
	- 导出操作 → 同步阻塞式生成 + 流式下载（`Content-Disposition: attachment`）


>⚠️ **局限性**：无 WebSocket，不支持实时协同编辑；所有操作需手动保存。


----

### 2.2 应用服务层（Application Layer）


基于 **Beego MVC 框架**，但实际演进为 **“Controller + Service-like Model”** 模式。

#### 2.2.1 路由层（Router）


- 定义位置：`routers/router.go`

- 路由类型：
	- 静态路由：`/login`, `/register`
	- 动态路由：`/docs/:key`, `/export/pdf/:key`
	- API 路由：`/api/book/update`, `/api/document/save`

- 路由映射示例：```
	beego.Router("/docs/:key", &controllers.BookController{}, "get:View")
	beego.Router("/export/pdf/:key", &controllers.BookController{}, "get:ExportPDF")
	beego.AutoRouter(&controllers.ApiController{})



#### 2.2.2 控制器层（Controller）


- **职责**：
	- HTTP 请求解析（`c.GetString("key")`）
	- 权限校验（`CheckMember()`）
	- 调用模型方法
	- 构造响应（模板渲染 / JSON / 文件流）

- **典型控制器**：
	- `BookController`：文档浏览、导出、设置
	- `AccountController`：登录、注册、个人中心
	- `ApiController`：提供 AJAX 接口（保存、删除、移动章节）

- **安全机制**：
	- CSRF 保护（Beego 内置）
	- Session 管理（基于 Cookie + 服务端存储）


2.2.3 模型层（Model）

- **ORM 框架**：Beego ORM（非 GORM）

- **核心模型**：

| 模型 | 对应表 | 关键字段 | 关系 |
|------|--------|--------|------|
| `User` | `users` | `id`, `username`, `password`, `email` | 1:N → `Member` |
| `Book` | `books` | `id`, `book_key`, `book_name`, `privately_owned` | 1:N → `Document`, 1:N → `Member` |
| `Document` | `documents` | `id`, `book_id`, `parent_id`, `markdown`, `sort` | 树形结构（自引用 parent_id） |
| `Member` | `members` | `book_id`, `user_id`, `role_id` | 多对多中间表 |


- **业务封装**：
	- `Book.FindByKey(key string)`：通过唯一 key 查找项目
	- `Document.GetTree(bookId int)`：递归构建文档目录树
	- `Member.CheckPermission(userId, bookId)`：验证用户角色


#### 2.2.4 服务辅助层（Service-like Logic）


虽然无显式 `service/` 目录，但复杂逻辑被封装在 **专用结构体** 中：


- `BookResult`（`models/BookResult.go`）：
	- 负责文档导出全流程
	- 方法：`ToEpub()`, `ToPdf()`, `ToDocx()`, `ToMobi()`
	- 内部调用 `exec.Command("ebook-convert", ...)` 执行外部命令
	- 临时文件管理：创建 `Temp/{uuid}/{book_key}/source` 目录结构


>✅ 这是系统**最复杂的业务单元**，也是修复的核心所在。


----

### 2.3 数据持久层（Persistence Layer）


#### 2.3.1 关系型数据库（MySQL / SQLite）


- **连接配置**：`conf/app.conf````
	mysqluser = root
	mysqlpass = root
	mysqlurls = 127.0.0.1:3306
	mysqldb   = mindoc
	目前项目临时采用sqlite库可满足基本需求，后续考虑采用MySQL
	```

- **迁移机制**：无自动 migration，首次启动时通过 `InstallController` 初始化表结构

- **事务使用**：极少，多数操作为单表写入


#### 2.3.2 文件系统存储


|存储类型 |路径 |生命周期 |访问方式 |
|:--|
|用户上传附件 |`uploads/{year}/{month}/{filename}` |永久 |HTTP 静态资源 (`/uploads/...`) |
|导出临时文件 |系统 Temp 目录（如 `C:\Users\...\Temp\{uuid}\`） |会话级（未清理） |仅后端访问 |
|日志文件 |`runtime/logs/` |滚动保留 |运维查看 |

>❗ **风险点**：临时文件未自动清理，长期运行可能占满磁盘。


----

### 2.4 外部依赖层（External Dependencies）


|组件 |类型 |调用方式 |配置项 |容错机制 |
|:--|
|`ebook-convert` |CLI 工具 |`exec.Command()` |`ebook_convert_command` |无重试，失败直接返回错误 |
|`wkhtmltopdf` |CLI 工具 |（部分分支） |`pdf_command` |未启用主流路径 |
|邮件服务 |SMTP |`gopkg.in/gomail.v2` |`smtp_*` 配置 |忘记密码时使用 |


- **路径问题**：
	- Windows 下需在 `app.conf` 中显式指定完整路径（如 `C:/Program Files/Calibre/ebook-convert.exe`）
	- Linux 下依赖 `$PATH` 环境变量


----

## 三、关键业务流程深度解析


### 3.1 文档导出流程（以 PDF 为例）



![流程图.png#616px #259px](/uploads/doc/images/m_c5339645498fd6e0668445b1a57955dc_r.png)


>🔍 **关键细节**：
- 所有中间文件（HTML、EPUB、CSS）均按 EPUB 标准组织
- PDF 样式通过 `--pdf-header-template` 等参数注入
- 若 `ebook-convert` 不存在，日志报错但前端无友好提示


----

### 3.2 权限控制模型


- **角色体系**：
	- `0`：普通成员（只读）
	- `1`：协作者（可编辑）
	- `2`：管理员（可管理成员、删除项目）

- **权限检查时机**：
	- 文档访问（`BookController.View`）
	- 编辑操作（`ApiController.SaveDocument`）
	- 导出操作（`BookController.ExportPDF`）

- **公开项目例外**：
	- 若 `book.privately_owned = 0`，则无需登录即可访问


----

## 四、可扩展性与定制点


|扩展方向 |实现方式 |难度 |
|:--|
|自定义导出样式 |修改 `BookResult.go` 中的 CSS 模板或 `ebook-convert` 参数 |★★☆ |
|增加新格式（如 PPTX） |在 `BookResult` 中新增 `ToPptx()` 并注册路由 |★★★ |
|集成 LDAP 登录 |重写 `AccountController.Login` 逻辑 |★★★ |
|自动清理临时文件 |在 `main.go` 启动时加定时任务 |★★ |
|支持对象存储（OSS/S3） |重写 `UploadController`，替换本地文件写入 |★★★★ |


----

## 五、部署与运维考量


- **部署模式**：单机部署（无集群支持）

- **性能瓶颈**：
	- 导出大文档时阻塞 HTTP 请求（同步执行）
	- 无缓存机制（每次导出都重新生成）

- **监控建议**：
	- 监控 `runtime/logs/` 错误日志
	- 定期清理 `Temp` 目录
	- 确保 `ebook-convert` 可用性


----

## 六、总结：MinDoc 的架构哲学


|维度 |特征 |
|:--|
|**设计目标** |快速私有化部署、开箱即用、功能完整 |
|**技术选型** |成熟稳定 > 新潮先进（Beego vs Gin/Fiber） |
|**复杂度控制** |业务逻辑集中，避免过度抽象 |
|**扩展思路** |通过配置和外部工具集成，而非内置所有能力 |
|**适用场景** |中小团队内部 Wiki、技术文档库、产品手册 |


----

>📌 **建议**：若需高可用、实时协同、多格式深度定制，可考虑迁移到 **Wiki.js** 或 **Outline**；若追求轻量、可控、私有化，MinDoc 仍是优秀选择。


----

你可以将此文档直接保存为 `ARCHITECTURE.md`，作为团队内部技术资产。如需进一步拆解某一部分（如“Beego ORM 如何映射 Document 树形结构”），欢迎继续深入提问！